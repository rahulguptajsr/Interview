You need to send the data to the server via POST request

the data is:

```
{

title: 'foo', body: 'bar', userId: 1

}
```
 
And the endpoint which you have to use to send your data will be:

`https://jsonplaceholder.typicode.com/posts`

You need to use HTML only to send the data to the server .


##After you finish making changes, upload the project in your personal github/gitlab account and make its visibility public and  then paste the project link in "Final project git url" input below

###Important Note:

You don’t have to use Javascript or CSS for this task. It should be done using pure HTML only
